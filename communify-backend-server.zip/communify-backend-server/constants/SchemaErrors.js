const interestSchemaErrors = {
  TITLE_REQUIRED: "Interest title is required",
  VALUE_REQUIRED: "Interest value is required",
};

module.exports = {
  interestSchemaErrors,
};
