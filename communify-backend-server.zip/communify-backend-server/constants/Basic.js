const postTypesEnum = ["PRODUCT", "SERVICE", "GENERAL", "IDEA", "EVENT"];
const postTypes = [
  { title: "Product", value: "PRODUCT" },
  { title: "Service", value: "SERVICE" },
  { title: "General", value: "GENERAL" },
  { title: "Idea", value: "IDEA" },
  { title: "Event", value: "EVENT" },
];

const serviceTypesEnum = ["DOCTOR", "LAWYER", "SALON"];
const serviceBookingTypesEnum = ["PENDING", "CONFIRMED", "CANCELLED"];

const serviceTypes = [
  { title: "Doctor", value: "DOCTOR" },
  { title: "Lawyer", value: "LAWYER" },
  { title: "Salon", value: "SALON" },
];

const serviceBookingTypes = {
  PENDING: "PENDING",
  CONFIRMED: "CONFIRMED",
  CANCELLED: "CANCELLED",
};

module.exports = {
  postTypesEnum,
  postTypes,
  serviceTypesEnum,
  serviceTypes,
  serviceBookingTypesEnum,
  serviceBookingTypes,
};
