const ERROR_MESSAGES = {
  UNIQUE_EMAIL: "Email address should be unique",
  INVALID_PASSWORD:
    "Password must contain at least 8 characters, including uppercase and lowercase letters",
  EMAIL_REQUIRED: "Email address is required",
  FIRST_NAME_REQUIRED: "First name is required",
  LAST_NAME_REQUIRED: "Last name is required",
  PASSWORD_REQUIRED: "Password is required",
  ROLE_REQUIRED: "Role is required",
  USERNAME_REQUIRED: "Username is required",
  PHONE_NO_REQUIRED: "Phone no is required",

  PASSWORD_REQUIRED: "Password is required",
  INVALID_JWT: `Invalid token! Please Login Again`,
  EXPIRED_JWT: `Your token has expired! please login again`,
  UNAUTHORIZE: "You are not authorize to perform this action",
  IMAGE_REQUIRED: `Image is required`,
  INVALID_LOGIN_CREDENTIALS: "Email or Password is Incorrect",
  INVALID_EMAIL: `Please Enter Valid Email`,
  NOT_FOUND: "Not Found",
  EMPTY_REQUIRED_FIELDS: "Required fields are empty.",
  INVALID_DATA: "Invalid data received.",
  USER_ALREADY_EXISTS: (userType) => {
    return `${userType} already exists with the provided email address`;
  },
  INVALID_OTP: "Invalid OTP Received!",
  USER_CREDENTIALS_NOT_FOUND: "User not found with provided credentials",
  USER_NOT_FOUND_WITH_EMAIL: "User not found with provided email address",
  INCORRECT_CURRENT_PASSWORD: "Incorrect current password!",
  USER_NOT_FOUND_WITH_ID: "User not found with provided identification number",
  UNAUTHORIZED_UPDATE_COMMUNITY:
    "You're not a authorize user to update this community",
  UNAUTHORIZED_DELETE_COMMUNITY:
    "You're not a authorize user to delete this community",

  COMMUNITIES_NOT_FOUND: "Communities not found",
  COMMUNITY_NOT_FOUND: "Community not found",
  COMMUNITY_ALREADY_EXISTS: "Community already exists with the provided title",

  POSTS_NOT_FOUND: "Posts not found",
  POST_NOT_FOUND: "Post not found",
  POST_ALREADY_EXISTS: "Community already exists with the provided title",
  INVALID_POST_TYPE: "Invalid Post Type",

  UNAUTHORIZED_UPDATE_POST: "You're not a authorize user to update this post",
  UNAUTHORIZED_DELETE_POST: "You're not a authorize user to delete this post",
  POST_TYPES_NOT_FOUND: "Post types not available",
  SERVICE_TYPES_NOT_FOUND: "Service types not available",
};

const UNAUTHORIZE_MESSAGES = {
  NOT_LOGGED_IN: `You are not logged in please login to get Access`,
  OTP_EXPIRED: "OTP Is Expired.",
  INVALID_JWT: `Invalid token! Please Login Again`,
  EXPIRED_JWT: `Your token has expired! please login again`,
  INVALID_EXPIRED: `Token is invalid or has been Expired`,
  INACTIVE_ACCOUNT:
    "Your account is deactivated, please contact your department admin.",
};

module.exports = {
  ERROR_MESSAGES,
  UNAUTHORIZE_MESSAGES,
};
