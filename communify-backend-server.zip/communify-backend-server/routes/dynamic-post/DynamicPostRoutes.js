const express = require("express");

const router = express.Router();

const {
  createPost,
  getAllPosts,
  deletePost,
  getSinglePost,
  updatePost,
  getAllPostTypes,
  getAllServiceTypes,
  getPostsForUser,
  updateIdeaPostVotes,
  updateEventPostInterest,
} = require("../../controllers/dynamic-post/DynamicPostController");

const { authenticateUser } = require("../../middlewares/Auth");

router.post("/create-new-post", authenticateUser, createPost);

router.get("/get-all-posts", authenticateUser, getAllPosts);

router.get("/get-all-post-types", authenticateUser, getAllPostTypes);

router.get("/get-all-service-types", authenticateUser, getAllServiceTypes);

router.get("/get-single-post/:postId", authenticateUser, getSinglePost);

router.get("/get-posts-for-user", authenticateUser, getPostsForUser);

router.delete("/delete-post/:postId", authenticateUser, deletePost);

router.put("/update-post/:postId", authenticateUser, updatePost);

router.patch(
  "/idea-post/vote/:ideaPostId",
  authenticateUser,
  updateIdeaPostVotes
);

router.patch(
  "/event-post/show-interest/:eventPostId",
  authenticateUser,
  updateEventPostInterest
);

module.exports = router;
