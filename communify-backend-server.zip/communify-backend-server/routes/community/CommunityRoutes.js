const express = require("express");

const router = express.Router();

const {
  createCommunity,
  getAllCommunities,
  getCommunityById,
  deleteCommunity,
  updateCommunity,
  suggestCommunitiesForUser,
  getUserCommunities,
  joinCommunity,
  leaveCommunity,
} = require("../../controllers/community/CommunityController");

const {
  getAllCommmunityPosts,
} = require("../../controllers/dynamic-post/DynamicPostController");

const { authenticateUser } = require("../../middlewares/Auth");

router.post("/create-community", authenticateUser, createCommunity);
router.get("/get-all-communities", authenticateUser, getAllCommunities);
router.get("/get-community/:communityId", authenticateUser, getCommunityById);

router.get(
  "/get-community-posts/:communityId",
  authenticateUser,
  getAllCommmunityPosts
);

router.delete(
  "/delete-community/:communityId",
  authenticateUser,
  deleteCommunity
);

router.put("/update-community/:communityId", authenticateUser, updateCommunity);

router.get(
  "/get-suggested-communities",
  authenticateUser,
  suggestCommunitiesForUser
);

router.post("/join-community/:communityId", authenticateUser, joinCommunity);
router.post("/leave-community/:communityId", authenticateUser, leaveCommunity);
router.get("/get-user-communities", authenticateUser, getUserCommunities);

module.exports = router;
