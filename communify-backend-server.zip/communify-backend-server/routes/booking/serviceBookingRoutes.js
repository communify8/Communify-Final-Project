const express = require("express");

const router = express.Router();

const {
  createBooking,
  getAllServiceBookings,
} = require("../../controllers/booking/serviceBookingController");

const { authenticateUser } = require("../../middlewares/Auth");

router.post("/create-booking", authenticateUser, createBooking);

router.get("/all-bookings", authenticateUser, getAllServiceBookings);

module.exports = router;
