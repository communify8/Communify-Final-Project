const express = require("express");

const router = express.Router();

const serviceBookingRouter = require("./serviceBookingRoutes");
const { SERVICE_BOOKING } = require("../../constants/Routes");

router.use(SERVICE_BOOKING, serviceBookingRouter);

module.exports = router;
