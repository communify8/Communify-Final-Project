const jwt = require("jsonwebtoken");

const ServerErrorResponse = require("../utils/classes/ServerErrorResponse");
const {
  STATUS_CODE,
  STATUS_MESSAGES,
  ACCOUNT_STATUS,
} = require("../constants/Status");
const { ERROR_MESSAGES, UNAUTHORIZE_MESSAGES } = require("../constants/Errors");

const User = require("../models/User");

const authenticateUser = async (req, res, next) => {
  //getting token and check is it there

  try {
    // Bearer jhkhkhkhkhkhkjhkh
    let token;
    if (
      req.headers.authorization &&
      req.headers.authorization.startsWith("Bearer")
    ) {
      token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
      return next(
        res
          .status(STATUS_CODE.UNAUTHORIZED)
          .json(
            ServerErrorResponse.customError(
              STATUS_MESSAGES.ERROR,
              STATUS_CODE.UNAUTHORIZED,
              UNAUTHORIZE_MESSAGES.NOT_LOGGED_IN,
              null
            )
          )
      );
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

    const currentTimestamp = Math.floor(Date.now() / 1000);
    if (decoded.exp < currentTimestamp) {
      return next(
        res
          .status(STATUS_CODE.UNAUTHORIZED)
          .json(
            ServerErrorResponse.customError(
              STATUS_MESSAGES.ERROR,
              STATUS_CODE.UNAUTHORIZED,
              UNAUTHORIZE_MESSAGES.EXPIRED_JWT,
              null
            )
          )
      );
    }

    const currentUser = await User.findById(decoded.userId);

    if (!currentUser) {
      return next(
        res
          .status(STATUS_CODE.UNAUTHORIZED)
          .json(
            ServerErrorResponse.customError(
              STATUS_MESSAGES.ERROR,
              STATUS_CODE.UNAUTHORIZED,
              ERROR_MESSAGES.NOT_FOUND,
              null
            )
          )
      );
    }

    req.user = currentUser;
    next();
  } catch (error) {
    const obj = {
      expired: true,
    };
    return next(
      res
        .status(STATUS_CODE.UNAUTHORIZED)
        .json(
          ServerErrorResponse.customError(
            STATUS_MESSAGES.ERROR,
            STATUS_CODE.UNAUTHORIZED,
            UNAUTHORIZE_MESSAGES.EXPIRED_JWT,
            obj
          )
        )
    );
  }
};

module.exports = {
  authenticateUser,
};
