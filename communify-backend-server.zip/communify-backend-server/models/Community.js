const mongoose = require("mongoose");

const communitySchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Community title is required"],
      unique: [true, "Community title should be unique"],
    },

    description: {
      type: String,
      required: [true, "Community description is required"],
      default: "",
    },
    creator: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
      default: null,
      ref: "User",
    },
    users: [
      {
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        default: [],
        ref: "User",
      },
    ],

    coverImage: {
      url: {
        type: String,
        required: false,
        default: "",
      },
      public_id: {
        type: String,
        required: false,
        default: "",
      },
      isUploaded: {
        type: Boolean,
        required: false,
        default: false,
      },
    },

    interests: [
      {
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        default: [],
        ref: "Interest",
      },
    ],

    isActive: {
      type: Boolean,
      required: false,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

const communityModel = mongoose.model("Community", communitySchema);

module.exports = communityModel;
