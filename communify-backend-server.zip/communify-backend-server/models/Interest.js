const mongoose = require("mongoose");

const { interestSchemaErrors } = require("../constants/SchemaErrors");

const interestSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, interestSchemaErrors.TITLE_REQUIRED],
      default: "",
    },
    value: {
      type: String,
      required: [true, interestSchemaErrors.VALUE_REQUIRED],
      default: "",
    },
    isActive: {
      type: Boolean,
      required: false,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

const interestModel = mongoose.model("Interest", interestSchema);

module.exports = interestModel;
