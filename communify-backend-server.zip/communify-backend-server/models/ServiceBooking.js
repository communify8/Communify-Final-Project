const mongoose = require("mongoose");
const {
  serviceBookingTypesEnum,
  serviceBookingTypes,
} = require("../constants/Basic");

const bookingSchema = new mongoose.Schema(
  {
    bookedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      default: null,
    },
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Post",
      required: false,
      default: null,
    },
    postOwner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: false,
      default: null,
    },
    bookingDate: { type: Date, required: false },
    status: {
      type: String,
      enum: serviceBookingTypesEnum,
      default: serviceBookingTypes.PENDING,
    },
  },
  { timestamps: true }
);

const Booking = mongoose.model("Booking", bookingSchema);

module.exports = Booking;
