const mongoose = require("mongoose");

const { ERROR_MESSAGES } = require("../constants/Errors");

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: [true, ERROR_MESSAGES.USERNAME_REQUIRED],
      unique: true,
    },
    firstName: {
      type: String,
      required: [true, ERROR_MESSAGES.FIRST_NAME_REQUIRED],
      default: "",
    },
    lastName: {
      type: String,
      required: [true, ERROR_MESSAGES.LAST_NAME_REQUIRED],
      default: "",
    },
    emailAddress: {
      type: String,
      required: [true, ERROR_MESSAGES.EMAIL_REQUIRED],
      unique: [true, ERROR_MESSAGES.UNIQUE_EMAIL],
      default: "",
    },
    phoneNo: {
      type: String,
      required: [true, ERROR_MESSAGES.PHONE_NO_REQUIRED],
      default: "",
    },
    password: {
      type: String,
      required: [true, ERROR_MESSAGES.PASSWORD_REQUIRED],
      default: "",
    },

    profileImage: {
      url: {
        type: String,
        required: false,
        default: "",
      },
      public_id: {
        type: String,
        required: false,
        default: "",
      },
      isUploaded: {
        type: Boolean,
        required: false,
        default: false,
      },
    },

    preferences: [
      {
        type: mongoose.Schema.Types.ObjectId,
        required: false,
        default: [],
        ref: "Interest",
      },
    ],

    isActive: {
      type: Boolean,
      required: false,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

const userModel = mongoose.model("User", userSchema);

module.exports = userModel;
