const ServiceBooking = require("../../models/ServiceBooking");
const { ServicePost, Post } = require("../../models/DynamicPost");
const { STATUS_CODE, STATUS_MESSAGES } = require("../../constants/Status");
const { ERROR_MESSAGES } = require("../../constants/Errors");
const { SUCCESS_MESSAGES } = require("../../constants/Success");

const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");

const createBooking = async (req, res) => {
  try {
    const { servicePostId, bookingDate } = req.body;
    const userId = req.user._id;

    const servicePost = await Post.findById(servicePostId);
    if (!servicePost) {
      return res
        .status(STATUS_CODE.NOT_FOUND)
        .json(ServerErrorResponse.notFound("Service post not found."));
    }

    const booking = new ServiceBooking({
      bookedBy: userId,
      post: servicePost._id,
      bookingDate,
      postOwner: servicePost.user,
    });

    const savedBooking = await booking.save();

    res
      .status(STATUS_CODE.CREATED)
      .json(
        ServerSuccessResponse.successResponse(
          true,
          STATUS_MESSAGES.SUCCESS,
          STATUS_CODE.CREATED,
          "Service has been booked sucessfully.",
          savedBooking
        )
      );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

const getAllServiceBookings = async (req, res) => {
  try {
    const currentUser = req.user;

    const bookingsMadeByUser = await ServiceBooking.find({
      bookedBy: currentUser._id,
    })
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    const bookingsMadeForUser = await ServiceBooking.find({
      postOwner: currentUser._id,
    })
      .populate("post")
      .populate(
        "bookedBy",
        "firstName lastName profileImage _id phoneNo emailAddress"
      )
      .populate(
        "postOwner",
        "firstName lastName profileImage _id phoneNo emailAddress"
      );

    res.status(STATUS_CODE.OK).json(
      ServerSuccessResponse.successResponse(
        true,
        STATUS_MESSAGES.SUCCESS,
        STATUS_CODE.OK,
        "Bookings found",
        {
          bookingsMadeByUser,
          bookingsMadeForUser,
        }
      )
    );
  } catch (error) {
    res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(
        ServerErrorResponse.customErrorWithStackTrace(
          STATUS_CODE.SERVER_ERROR,
          STATUS_MESSAGES.SERVER_ERROR,
          error
        )
      );
  }
};

module.exports = {
  createBooking,
  getAllServiceBookings,
};
