const ServiceBooking = require("../../models/ServiceBooking");
const { ServicePost, Post } = require("../../models/DynamicPost");
const { STATUS_CODE, STATUS_MESSAGES } = require("../../constants/Status");
const { ERROR_MESSAGES } = require("../../constants/Errors");
const { SUCCESS_MESSAGES } = require("../../constants/Success");
const Stripe = require("stripe");

const ServerErrorResponse = require("../../utils/classes/ServerErrorResponse");
const ServerSuccessResponse = require("../../utils/classes/ServerSuccessResponse");

const createPaymentIntent = async (req, res) => {
  try {
    const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
    const { amount } = req.body;

    console.log(
      "process.env.STRIPE_SECRET_KEY: ",
      process.env.STRIPE_SECRET_KEY
    );

    let totalAmount = amount * 100;

    const paymentIntent = await stripe.paymentIntents.create({
      amount: totalAmount,
      currency: "PKR",
      automatic_payment_methods: {
        enabled: true,
      },
    });

    res.status(STATUS_CODE.CREATED).json(
      ServerSuccessResponse.successResponse(
        true,
        STATUS_MESSAGES.SUCCESS,
        STATUS_CODE.CREATED,
        SUCCESS_MESSAGES.CREATED,
        {
          clientSecret: paymentIntent.client_secret,
          stripeAmount: totalAmount,
          actualAmount: amount,
          currency: paymentIntent.currency,
        }
      )
    );
  } catch (error) {
    return res
      .status(STATUS_CODE.SERVER_ERROR)
      .json(ServerErrorResponse.internal(error));
  }
};

module.exports = {
  createPaymentIntent,
};
